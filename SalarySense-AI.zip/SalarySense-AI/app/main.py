"""
SalarySense AI - API + dashboard server
=======================================
Run:   python -m uvicorn app.main:app --reload
Open:  http://localhost:8000

Endpoints
  GET    /api/health      is the model loaded?
  GET    /api/options     dropdown values the model knows
  POST   /api/predict     salary + 80% range + K-Means band (saved to history)
  GET    /api/history     last predictions
  DELETE /api/history     clear history
  GET    /api/analytics   data insights (charts)
  GET    /api/model       metrics, comparison, importance, bands
"""
import json
import os
import sqlite3
import threading
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parent.parent
MODEL_FILE = BASE / "models" / "salary_model.joblib"
META_FILE = BASE / "models" / "metadata.json"
STATIC = Path(__file__).resolve().parent / "static"
DB_FILE = Path(os.environ.get("SALARYSENSE_DB", BASE / "data" / "history.db"))

state = {"model": None, "meta": None}
_db_lock = threading.Lock()


# ----------------------------------------------------------------- history (SQLite)
def db():
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS history (
        id TEXT PRIMARY KEY, created_at TEXT, age INTEGER, experience REAL, gender TEXT,
        education TEXT, job_title TEXT, predicted REAL, low REAL, high REAL, band TEXT)""")
    return con


@asynccontextmanager
async def lifespan(app: FastAPI):
    if MODEL_FILE.exists() and META_FILE.exists():
        state["model"] = joblib.load(MODEL_FILE)
        state["meta"] = json.loads(META_FILE.read_text(encoding="utf-8"))
        print("Model loaded. Open http://localhost:8000")
    else:
        print("WARNING: model not found. Run:  python train.py")
    yield


app = FastAPI(title="SalarySense AI", version="2.0.0", lifespan=lifespan)


# ----------------------------------------------------------------- schemas
class PredictIn(BaseModel):
    age: int = Field(ge=18, le=70)
    experience: float = Field(ge=0, le=45)
    gender: str
    education: str
    job_title: str


def require_model():
    if state["model"] is None:
        raise HTTPException(503, "Model not trained yet. Run: python train.py")
    return state["model"], state["meta"]


def assign_band(km, experience, salary):
    """Nearest K-Means centre (in standardised units) -> band name."""
    mean, scale = np.array(km["mean"]), np.array(km["scale"])
    point = (np.array([experience, salary]) - mean) / scale
    centers = (np.array(km["centers"]) - mean) / scale
    return km["names"][int(np.argmin(((centers - point) ** 2).sum(axis=1)))]


# ----------------------------------------------------------------- routes
@app.get("/api/health")
def health():
    return {"status": "ok", "model_loaded": state["model"] is not None,
            "trained_at": (state["meta"] or {}).get("trained_at")}


@app.get("/api/options")
def options():
    _, meta = require_model()
    return meta["options"]


@app.post("/api/predict")
def predict(body: PredictIn):
    model, meta = require_model()
    opt = meta["options"]
    errors = []
    if body.gender not in opt["genders"]:
        errors.append(f"gender must be one of {opt['genders']}")
    if body.education not in opt["educations"]:
        errors.append(f"education must be one of {opt['educations']}")
    if body.job_title not in opt["job_titles"]:
        errors.append("job_title is not in the list of known job titles")
    if not opt["age"][0] <= body.age <= opt["age"][1]:
        errors.append(f"age must be between {opt['age'][0]} and {opt['age'][1]} (the range the model was trained on)")
    if body.experience > opt["experience"][1]:
        errors.append(f"experience must be at most {opt['experience'][1]} years (the range the model was trained on)")
    if body.experience > body.age - 14:
        errors.append("experience is too high for this age (experience must be at most age - 14)")
    if errors:
        raise HTTPException(422, "; ".join(errors))

    row = pd.DataFrame([{"age": body.age, "experience": body.experience, "gender": body.gender,
                         "education": body.education, "job_title": body.job_title}])
    for c in ("gender", "education", "job_title"):
        row[c] = row[c].astype(object)
    salary = float(model.predict(row)[0])

    iv = meta["interval"]
    low, high = salary * (1 + iv["rel_q10"]), salary * (1 + iv["rel_q90"])
    band = assign_band(meta["kmeans"], body.experience, salary)

    rec = {"id": uuid.uuid4().hex[:10], "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
           **body.model_dump(), "predicted": round(salary), "low": round(low), "high": round(high), "band": band}
    with _db_lock:
        con = db()
        con.execute("INSERT INTO history VALUES (:id,:created_at,:age,:experience,:gender,:education,:job_title,:predicted,:low,:high,:band)", rec)
        con.commit()
        con.close()
    return {"id": rec["id"], "predicted_salary": rec["predicted"], "lower": rec["low"], "upper": rec["high"],
            "band": band, "interval_level": iv["level"], "model_r2": meta["final"]["R2"],
            "model_mae": meta["final"]["MAE"], "currency": "USD"}


@app.get("/api/history")
def history(limit: int = 20):
    with _db_lock:
        con = db()
        rows = [dict(r) for r in con.execute("SELECT * FROM history ORDER BY created_at DESC, rowid DESC LIMIT ?", (max(1, min(limit, 200)),))]
        con.close()
    return rows


@app.delete("/api/history")
def clear_history():
    with _db_lock:
        con = db()
        con.execute("DELETE FROM history")
        con.commit()
        con.close()
    return {"cleared": True}


@app.get("/api/analytics")
def analytics():
    _, meta = require_model()
    return {**meta["analytics"], "kmeans_sample": meta["kmeans"]["sample"],
            "bands": meta["kmeans"]["bands"], "cleaning": meta["dataset"]["cleaning"]}


@app.get("/api/model")
def model_info():
    _, meta = require_model()
    return {k: meta[k] for k in ("trained_at", "sklearn_version", "split", "comparison", "best_params",
                                  "final", "interval", "importance", "fairness", "scatter")} | {
        "dataset": meta["dataset"], "kmeans": {k: v for k, v in meta["kmeans"].items() if k != "sample"}}


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")


app.mount("/static", StaticFiles(directory=STATIC), name="static")
