# Viva Guide — SalarySense AI (Roman Urdu)

Numbers neeche meri run ke hain. Aapki run mein thoda sa farq aa sakta hai, isliye viva se pehle
dashboard ka **Model** tab ya `docs/REPORT_DRAFT.md` se apne numbers check kar lena.

## 1. Project 30 seconds mein
"SalarySense AI ek salary prediction aur analytics dashboard hai. User age, experience, gender, education
aur job title daalta hai. Backend ka trained Random Forest yearly salary (USD) predict karta hai, saath
80% prediction range aur K-Means se salary band batata hai. Dashboard par data insights, model ki
evaluation aur prediction history bhi hai."

## 2. Flow (board par draw karo)
```
Browser form  ->  POST /api/predict  ->  FastAPI (app/main.py)
   -> Pipeline: Imputer -> Scaler + OneHotEncoder -> Random Forest   -> salary
   -> range = salary x (1 + q10) .. salary x (1 + q90)
   -> band  = nearest K-Means centre
   -> SQLite mein history save  ->  browser mein result
```

## 3. Dataset (sabse pehle ye poochenge)
- Kaggle-origin "Salary Data": 6,704 rows, 6 columns (Age, Gender, Education Level, Job Title, Years of Experience, Salary).
  File GitHub mirror se li hai; Kaggle ka original page report mein cite karna.
- **Cleaning (Lab 1)** — 6,704 se 1,783 rows bache:
  - 5 rows ki salary missing thi, drop kiye (target ko impute nahi karte)
  - Education ke 7 spellings the ("Bachelor's", "Bachelor's Degree", "phD"...), unko 4 levels bana diya
  - **4,912 duplicate rows** hataye. Warna ek hi row train aur test dono mein aa jati aur score jhoota ho jata
  - 4 salaries 10,000 se kam thin (jaise 350), data-entry error samajh ke hataye
  - 192 job titles ko 59 mein group kiya (jo 5 se kam rows mein the wo "Other")
  - Baaki chhote missing values pipeline ke andar impute hote hain (numbers: median, text: most frequent)

## 4. Concepts apni zabaan mein
- **Train/test split (80/20):** 80% par model seekhta hai, 20% par imtihan. Test data ko training mein kabhi nahi chuna.
- **OneHotEncoder:** text ko 0/1 columns mein badalta hai, taake model "Director" ko "Analyst" se bada number na samjhe.
  `handle_unknown="ignore"` matlab nayi category aaye to error nahi, sab zero.
- **Linear Regression (Lab 2):** seedhi line/plane. Baseline. R² ~0.81.
- **Decision Tree (Lab 4):** if-else sawalon ka tree. Akela tree overfit karta hai. R² ~0.80.
- **Random Forest (Lab 5):** bohat se trees, har tree data ke random hisse (bagging) aur random features par seekhta hai.
  Final jawab sab ka average. R² ~0.90.
- **GridSearchCV (CLO-2):** hyperparameters ke combinations try karta hai, cross-validation se best chunta hai.
- **Cross-validation:** training data ke 5 hisse, 4 par train 1 par test, 5 baar. Score stable hai ya nahi, pata chalta hai.
- **Metrics:** MAE = average galti dollars mein (~$10,900). RMSE = badi galtiyon ko zyada saza. R² = model kitna fark samjhata hai (1 = perfect).
- **K-Means (Lab 10):** (experience, salary) par 4 groups. Elbow aur silhouette se k check kiya.
- **Permutation importance:** ek column ko shuffle karo, score kitna girta hai. Zyada girna = zyada zaroori column.
  Experience ~56%, job title ~21%, age ~14%, education ~8%, gender ~1%.

## 5. 80% range kaise bani (viva ka acha sawal)
1. Training data par 5-fold cross-validation se predictions li (jo model ne us row par seekhi nahi thi).
2. Relative error = (actual - predicted) / predicted nikala.
3. Uske 10th aur 90th percentile: -18.6% aur +15.3%.
4. Har prediction P ke liye range = P x 0.814 se P x 1.153.
5. **Check:** test data par asli salary 83.8% dafa is range ke andar aayi (target 80%). Yani range sahi calibrated hai.

## 6. Sawal jo sir poochenge, aur sachay jawab

**Random Forest kyun?** Comparison table ne faisla kiya: RF R² 0.90, Linear Regression 0.81, Decision Tree 0.80.
Salary job title, experience aur education ke combination par non-linear depend karti hai, jo RF pakadta hai.

**Tuning se fayda hua?** Nahi, sach ye hai. Tuned forest ka test R² 0.898 hai aur default ka 0.906. Ye farq cross-validation
ki std (~0.01-0.02) ke andar hai, yani koi asli fark nahi. Isliye report mein likha hai ke tuning se khaas improvement nahi mila.

**K-Means ka k=4 kyun, silhouette to k=2 par best hai?** Haan, k=2 par silhouette 0.55 hai aur k=4 par 0.46. Elbow plot mein inertia k=4 tak tezi se girta hai aur uske baad flat ho jata hai, isliye k=4 chuna, aur 4 salary bands samajhne mein asaan bhi hain. k=2 sirf 2 groups deta (kam/zyada), jo kaam ka nahi. Ye ek trade-off hai aur main khulkar maanta hoon. Bands overlap karte hain
(105k salary "Medium" bhi ho sakti hai "High" bhi).

**Gender model mein kyun hai? Bias?** Data mein male average salary (~$118k) female (~$108k) se zyada hai, lekin model mein
gender ki importance sirf ~1% hai; gap ka bara hissa experience aur job title se aata hai. Fairness table mein gender-wise
average error -1.3% aur +1.0% hai. Real use mein protected attributes hata dena ya audit karna chahiye.

**Limitations?** Sirf 1,783 unique rows; country/company column nahi, salary USD mein hai (Pakistan ke liye nahi);
age aur experience aapas mein bohat related hain; range ye maanti hai ke future ki galtiyan past jaisi hongi.

**Ye project dost ne banaya tha?** (Agar poochen) Seedha jawab: "Maine is project ko dobara design aur rebuild kiya, har file samajh kar."
Ye tabhi sach hoga jab aap neeche ka section padh loge.

## 7. Code samajhne ka order (1 ghanta)
1. `train.py` ko upar se neeche padho: `clean_data` -> `make_preprocessor` -> `main`. Har step ka comment padho.
2. `app/main.py`: `predict()` function ko line by line (validation -> model.predict -> range -> band -> SQLite).
3. Dashboard chalao, ek prediction karo, browser mein F12 > Network > `predict` response dekho.
4. `outputs/figures/` ke graphs dekho (report ke liye bhi chahiye).

## 8. Demo checklist
1. `run.bat` chalao, `http://localhost:8000` khulne do
2. 2-3 predictions karo (junior vs senior, High School vs PhD) aur dikhao ke salary sahi direction mein badalti hai
3. Ek galat input try karo (age 22, experience 15), error message dikhao
4. Data insights, Model, History tabs dikhao
5. Terminal mein `python -m pytest -q` chalao (15 tests pass)
