"""API tests. Run:  python -m pytest -q   (train the model first: python train.py)"""
import os
import tempfile

import pytest
from fastapi.testclient import TestClient

os.environ["SALARYSENSE_DB"] = os.path.join(tempfile.mkdtemp(), "test_history.db")

from app.main import app  # noqa: E402

GOOD = {"age": 30, "experience": 5, "gender": "Male", "education": "Bachelor's", "job_title": "Software Engineer"}


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        if not c.get("/api/health").json()["model_loaded"]:
            pytest.skip("model not trained - run python train.py first")
        yield c


def test_health(client):
    assert client.get("/api/health").json()["status"] == "ok"


def test_options_contain_dropdown_values(client):
    o = client.get("/api/options").json()
    assert "Male" in o["genders"] and "PhD" in o["educations"] and "Other" in o["job_titles"]


def test_predict_returns_range_and_band(client):
    r = client.post("/api/predict", json=GOOD)
    assert r.status_code == 200
    b = r.json()
    assert b["lower"] < b["predicted_salary"] < b["upper"]
    assert b["band"] in {"Low pay", "Medium pay", "High pay", "Top pay"}


def test_more_experience_means_higher_salary(client):
    junior = client.post("/api/predict", json={**GOOD, "experience": 1, "age": 25}).json()["predicted_salary"]
    senior = client.post("/api/predict", json={**GOOD, "experience": 15, "age": 40}).json()["predicted_salary"]
    assert senior > junior


def test_education_matters(client):
    hs = client.post("/api/predict", json={**GOOD, "education": "High School"}).json()["predicted_salary"]
    phd = client.post("/api/predict", json={**GOOD, "education": "PhD"}).json()["predicted_salary"]
    assert phd > hs


@pytest.mark.parametrize("change", [
    {"gender": "Robot"}, {"education": "Kindergarten"}, {"job_title": "Wizard"},
    {"age": 22, "experience": 15},       # started working at age 7
    {"age": 10}, {"experience": -1}, {"experience": 99},
])
def test_invalid_input_is_rejected(client, change):
    assert client.post("/api/predict", json={**GOOD, **change}).status_code == 422


def test_history_saves_and_clears(client):
    client.delete("/api/history")
    client.post("/api/predict", json=GOOD)
    rows = client.get("/api/history").json()
    assert len(rows) == 1 and rows[0]["job_title"] == "Software Engineer"
    client.delete("/api/history")
    assert client.get("/api/history").json() == []


def test_analytics_and_model_endpoints(client):
    a = client.get("/api/analytics").json()
    assert {"kpi", "salary_histogram", "top_job_titles", "bands"} <= a.keys()
    m = client.get("/api/model").json()
    assert m["final"]["R2"] > 0.8 and len(m["comparison"]) == 4
    assert abs(sum(m["importance"].values()) - 1) < 0.01
    assert 0.7 < m["interval"]["test_coverage"] < 0.95


def test_dashboard_page_is_served(client):
    r = client.get("/")
    assert r.status_code == 200 and "SalarySense" in r.text
